# -*- coding: utf-8 -*-
"""
Created on Wed May  6 15:48:29 2020

@author: K
"""
import numpy as np

def cal_M(p,ds,dt):
    n = p[0]
    f = 1000
    l = -(0.5-ds)*p[1]
    r =  (0.5+ds)*p[1]
    t =  (0.5-dt)*p[2]
    b = -(0.5+dt)*p[2]
    m=np.zeros([4,4])
    m[0,0] = 2*n / (r-l)
    m[1,1] = 2*n / (t-b)
    m[0,2] = (r+l) / (r-l)
    m[1,2] = (t+b) / (t-b)
    m[2,2] = (n+f) / (n-f)
    m[2,3] = 2*n*f / (n-f)
    m[3,2] = -1
    return m

def com_pm(pl,pr,xc,yc):
    ds = (pr[3]-pl[3])/2
    dt = (pr[4]-pl[4])/2
    ds = ds - xc
    dt = dt - yc
    
    mL = cal_M(pl,ds,dt)
    mR = cal_M(pr,ds,dt)
    mL = np.around(mL.T ,decimals=6)          #unity以列为主序
    mR = np.around(mR.T ,decimals=6)
    
    fid = open('NibiruProjectionConfig.txt','w+')
    fid.write("lefteye = ")
    for i in range(4):
        for j in range(4):
            fid.write(str(mL[i,j]))
            if i+j < 6:
                fid.write(',')
            else:
                fid.write('\n')
    fid.write("righteye= ")
    for i in range(4):
        for j in range(4):
            fid.write(str(mR[i,j]))
            if i+j < 6:
                fid.write(',')
            else:
                fid.write('\n')            
    
    
    fid.close()    
    
    
















