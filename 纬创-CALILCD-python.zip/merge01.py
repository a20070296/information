
import numpy as np
import time
import os
import shutil
import CaliVR
import cv2
import recheck01
import sys 
import tkinter

def CreateFile(name,t1,t2,s): #定义创建文件
    f1=open(name,'w+')
    
    a1=1
    a2=2
    g=1
    if s==0:
        a1,a2=a2,a1
        
    filename1='Cape'+str(a1)
    filename2='Cape'+str(a2)
    f1.write('SubAddress 0x6c # device 8-bit I2C sub address is 0x6C \n')
    f1.write('RegAddrWidth 16 # 16-bit address \n')
    f1.write('RegAddress 0x000A # register address 0x000A \n')
    f1.write('Read 2 # read 2 bytes \n')
    f1.write('Write 0xA3 0x30 # write 0xA330 to register 0x000A \n')
    f1.write('Display no # Disable display to avoid frame drop during image capture \n')
    f1.write('Delay 100 # delay 100ms  \n')
    f1.write('InterFrameDelay 10 # delay 10 ms after each frame is captured \n')
    f1.write('Capture 1 '+filename1+' '+filename2+'  \n')
    f1.write('Display yes # enable Display \n')
    f1.write('intExp '+str(t1)+' '+ str(g)+' '+str(t2)+' '+ str(g)+'\n')
    # f1.write('intExp2 '+str(t2)+' '+ str(g)+ '\n')
    f1.close()

def cal_M(p,ds,dt): #五点转换为投影矩阵
    n = p[0]
    f = 1000
    l = -(0.5-ds)*p[1]
    r =  (0.5+ds)*p[1]
    t =  (0.5-dt)*p[2]
    b = -(0.5+dt)*p[2]
    m=np.zeros([4,4])
    m[0,0] = 2*n / (r-l)
    m[1,1] = 2*n / (t-b)
    m[0,2] = (r+l) / (r-l)
    m[1,2] = (t+b) / (t-b)
    m[2,2] = (n+f) / (n-f)
    m[2,3] = 2*n*f / (n-f)
    m[3,2] = -1
    return m

def com_pm(pl,pr,xc,yc):
    ds = (pr[3]-pl[3])/2
    dt = (pr[4]-pl[4])/2
    ds = ds - xc
    dt = dt - yc
    
    mL = cal_M(pl,ds,dt)
    mR = cal_M(pr,ds,dt)
    mL = np.around(mL.T ,decimals=6)          #unity以列为主序
    mR = np.around(mR.T ,decimals=6)
    
    fid = open('NibiruProjectionConfig.txt','w+')
    fid.write("lefteye = ")
    for i in range(4):
        for j in range(4):
            fid.write(str(mL[i,j]))
            if i+j < 6:
                fid.write(',')
            else:
                fid.write('\n')
    fid.write("righteye= ")
    for i in range(4):
        for j in range(4):
            fid.write(str(mR[i,j]))
            if i+j < 6:
                fid.write(',')
            else:
                fid.write('\n')            
    
    
    fid.close()    

def cameraCali(): #根据txt文件生成双目内参
    def readtxt(P,m,n):
        r=np.zeros((m,n))
        for i in range(len(P)):
            c=P[i].strip('\n').split(',')
            r[i,:]=c[:]
        return r
        
    f=open('cameraconfig.txt')
    c=f.readlines()
    left_camera_matrix = readtxt(c[0:3],3,3)
    left_distortion=readtxt(c[3:4],1,5)
    right_camera_matrix = readtxt(c[4:7],3,3)
    right_distortion=readtxt(c[7:8],1,5)
    R = readtxt(c[8:11],3,3)
    T = readtxt(c[11:14],3,1)
    f.close()
    size = (1280,720)
    f1 = (left_camera_matrix[0,0]+left_camera_matrix[1,1])/2
    f2 = (right_camera_matrix[0,0]+right_camera_matrix[1,1])/2
    R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(left_camera_matrix, left_distortion,
                                                                      right_camera_matrix, right_distortion, size, R,
                                                                      T)
    # 计算更正map
    left_map1, left_map2 = cv2.initUndistortRectifyMap(left_camera_matrix, left_distortion, R1, P1, size, cv2.CV_16SC2)
    right_map1, right_map2 = cv2.initUndistortRectifyMap(right_camera_matrix, right_distortion, R2, P2, size, cv2.CV_16SC2)
    return left_map1, left_map2,right_map1, right_map2,f1,f2

left_map1, left_map2,right_map1, right_map2,f1,f2=cameraCali()

def exptime():
    
    def a():
        form.destroy()
    form=tkinter.Tk()
    form.title('调整曝光时间长短')
    form.minsize(300,200)
    
    l1 = tkinter.Label(form,text="相机A曝光大小（整数）：").pack()
    num_x = tkinter.StringVar()
    entryx = tkinter.Entry(form,textvariable = num_x).pack()
    num_x.set("20")
    
    l2 = tkinter.Label(form,text="相机B曝光大小（整数）：").pack()
    num_y = tkinter.StringVar()
    entryy = tkinter.Entry(form,textvariable = num_y).pack()
    num_y.set("20")
    
    bt1=tkinter.Button(form,text='确定',command = a,background='red' )
    bt1.pack(padx=50,pady=20, side=tkinter.BOTTOM)
    form.mainloop()

    return num_x.get(),num_y.get()
    
et1,et2 = exptime()

#################################
print('start progress...')

os.system("001.bat")  #run 001.bat
time.sleep(1)  #pause 1 s

s=1
f1="isLeftCamera.txt"
if os.path.isfile(f1):
    f=open(f1)
    s=int(f.read()[0])
et1,et2 = 20,20
CreateFile('1.txt',et1,et2,s)
shutil.move('1.txt', './camera/1.txt')

os.system('adb shell input keyevent 224')
time.sleep(1.5)

print('start capture...')
os.chdir(os.getcwd()+'/camera/')   #更改运行目录
os.system('CameraTool1.exe')
os.system('adb shell input keyevent 224')
time.sleep(2.5)
os.system('CameraTool2.exe')
os.chdir(os.getcwd()[:-6])      #返回主目录
shutil.move('./camera/Cape1_1.bmp','L01.bmp')
shutil.move('./camera/Cape2_1.bmp','R01.bmp')
print('capture finish ...')

######################################

img_left = cv2.imread('L01.bmp',0)
img_right = cv2.imread('R01.bmp',0)

PL,PR = CaliVR.caliVR(img_left,img_right)

xc,yc = 0,0

com_pm(PL,PR,xc,yc)

print('projection matrix have completed ...')
######################################
# CreateFile('1.txt',10,10,s)
# shutil.move('1.txt', './camera/1.txt')
# print('the maching will be reboot ...')
os.system("002.bat")  #run 002.bat

os.system('adb wait-for-device，adb shell input keyevent 224')

time.sleep(0.5)

os.system('adb shell am start -n com.nibiru.sdcarddemo/com.nibiru.sdcarddemo.MainActivity')
print('start capture again...')
os.chdir(os.getcwd()+'/camera/')
os.system('CameraTool1.exe')
os.system('adb shell input keyevent 224')
time.sleep(2.5)
os.system('CameraTool2.exe')
os.chdir(os.getcwd()[:-6])
shutil.move('./camera/Cape1_1.bmp','L02.bmp')
shutil.move('./camera/Cape2_1.bmp','R02.bmp')
print('capture finish ...')

###########################################
#检测结果
'''
def recheck(img_left2,img_right2):
    imgL2 = cv2.remap(img_left2, left_map1, left_map2, cv2.INTER_LINEAR)
    imgR2 = cv2.remap(img_right2, right_map1, right_map2, cv2.INTER_LINEAR)
    
    circles_left2 = cv2.HoughCircles(imgL2, cv2.HOUGH_GRADIENT, 1, 20,\
                               param1=100, param2=20, minRadius=10,maxRadius=30)
    
    circles_right2 = cv2.HoughCircles(imgR2, cv2.HOUGH_GRADIENT, 1, 20,\
                               param1=100, param2=20, minRadius=10,maxRadius=30)
    for i in circles_left2[0,:,:]:
        cv2.circle(imgL2, (i[0], i[1]), i[2], (0, 0, 255), 1)
        cv2.circle(imgL2, (i[0], i[1]), 2, (0, 0, 255), 1)
    
    for i in circles_right2[0,:,:]:
        cv2.circle(imgR2, (i[0], i[1]), i[2], (0, 0, 255), 1)
        cv2.circle(imgR2, (i[0], i[1]), 2, (0, 0, 255), 1)
    #图像水平拼接
    img2 = np.hstack((imgL2,imgR2))
    cv2.imwrite('p1.jpg',img2)
        
    if (circles_left2.shape[1] != 9)|(circles_right2.shape[1] != 9):   #异常检测
        print('The number of points is error ! It should be 9!')
        sys.exit(0)    
    
    a1=np.mean(circles_left2,axis=1)
    a2=np.mean(circles_right2,axis=1)
    
    
    fid = open('result.txt','w+')
    fid.write('the central vertical difference is '+str(a1[0,1]-a2[0,1]))
    fid.close()
    
img_left2 = cv2.imread('L02.bmp',0)
img_right2 = cv2.imread('R02.bmp',0)

recheck(img_left2,img_right2)
'''

