import cv2
import numpy as np
 
#左摄像头参数
left_camera_matrix = np.array([[1600.15504563114,  -1.68443824828496 ,   687.032727018796],
                               [0, 1600.93874832329, 338.304525618217],
                               [0, 0, 1]])
left_distortion = np.array([[ -0.591019058621632 , 0.536675403589903, 0.00266814876146942 , -0.00201297590399573 , -0.965527276778518]])
 
#右摄像头参数
right_camera_matrix = np.array([[1605.67781330744, -2.57711575429421, 628.120445076394],
                                [0, 1607.07712316075, 345.778733154269],
                                [0, 0, 1]])
right_distortion = np.array([[-0.595388409997052 , 0.488045259360664  ,0.00332540576619614 ,-0.00486253414008967, -0.585527546281574]])
 
#om = np.array([0.00456, 0.01463, 0.00042])        # 旋转关系向量
#R = cv2.Rodrigues(om)[0]                           # 使用Rodrigues变换将om变换为R
R = np.array([[0.999981599873067, 0.00606330660050077 , 0.000190337514653901],
              [-0.00606503177827766 , 0.999921261483658 ,0.0109857281260134],
              [-0.000123712689902660 ,-0.0109866803902964 , 0.999939636952737]])
T = np.array([-63.427746924968570,-0.465885037404077,1.148258048123125])      # 平移关系向量
 
size = (1280, 720) # 图像尺寸
 
# 进行立体更正
R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(left_camera_matrix, left_distortion,
                                                                  right_camera_matrix, right_distortion, size, R,
                                                                  T)
# 计算更正map
left_map1, left_map2 = cv2.initUndistortRectifyMap(left_camera_matrix, left_distortion, R1, P1, size, cv2.CV_16SC2)
right_map1, right_map2 = cv2.initUndistortRectifyMap(right_camera_matrix, right_distortion, R2, P2, size, cv2.CV_16SC2)
#print('roi1',P2)