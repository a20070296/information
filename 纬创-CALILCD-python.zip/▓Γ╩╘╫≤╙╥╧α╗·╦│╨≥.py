# -*- coding: utf-8 -*-
"""
Created on Sat May  9 18:20:09 2020

@author: K
CameraTool.exe用于生成CameraUUID.txt
CameraTool1.exe用于拍摄camera0图像
生成1.txt
"""


import tkinter
import os
import time

os.chdir(os.getcwd()+'/camera/')   #更改运行目录
os.system('start CameraTool.exe')

time.sleep(1.6)

def a():
    print('left camera')
    fid = open('CameraUUID.txt','a+')
    fid.write('left'+'\n')
    fid.close()
    #form.quit()
    form.destroy()
    os.system(r'taskkill /F /IM CameraTool.exe')

def b():
    print('rigth camera')
    fid = open('CameraUUID.txt','a+')
    fid.write('right'+'\n')
    fid.close()
    #form.quit()
    form.destroy()
    os.system(r'taskkill /F /IM CameraTool.exe')


form=tkinter.Tk()
form.title('点击选择是哪个相机')
form.minsize(300,100)
bt1=tkinter.Button(form,text='left camera',command = a,background='red' )
bt1.pack(padx=50,pady=50, side=tkinter.LEFT)
bt1=tkinter.Button(form,text='right camera',command = b,background='yellow' )
bt1.pack(padx=50,pady=50,side=tkinter.RIGHT)

form.mainloop()
os.system(r'taskkill /F /IM CameraTool.exe')