# -*- coding: utf-8 -*-
"""
Created on Thu Apr 30 13:46:23 2020

@author: K
"""
def CreateFile(name,t1,t2,s):
    f1=open(name,'w+')
    
    a1=1
    a2=2
    g=1
    if s==1:
        a1,a2=a2,a1
        
    filename1='Cape'+str(a1)
    filename2='Cape'+str(a2)
        
    f1.write('SubAddress 0x6c # device 8-bit I2C sub address is 0x6C \n')
    f1.write('RegAddrWidth 16 # 16-bit address \n')
    f1.write('RegAddress 0x000A # register address 0x000A \n')
    f1.write('Read 2 # read 2 bytes \n')
    f1.write('Write 0xA3 0x30 # write 0xA330 to register 0x000A \n')
    f1.write('Display no # Disable display to avoid frame drop during image capture \n')
    f1.write('Delay 100 # delay 100ms  \n')
    f1.write('InterFrameDelay 10 # delay 10 ms after each frame is captured \n')
    f1.write('Capture 1 '+filename1+' '+filename2+'  \n')
    f1.write('Display yes # enable Display \n')
    f1.write('intExp1 '+str(t1)+' '+ str(g)+'\n')
    f1.write('intExp2 '+str(t2)+' '+ str(g)+ '\n')
    
    
    f1.close()
s=0
CreateFile('1.txt',200,350,s)