# -*- coding: utf-8 -*-
"""
Created on Wed May  6 17:21:11 2020

@author: K
"""
import cv2
import numpy as np
import sys

def cameraCali():
    def readtxt(P,m,n):
        r=np.zeros((m,n))
        for i in range(len(P)):
            c=P[i].strip('\n').split(',')
            r[i,:]=c[:]
        return r
        
    f=open('cameraconfig.txt')
    c=f.readlines()
    left_camera_matrix = readtxt(c[0:3],3,3)
    left_distortion=readtxt(c[3:4],1,5)
    right_camera_matrix = readtxt(c[4:7],3,3)
    right_distortion=readtxt(c[7:8],1,5)
    R = readtxt(c[8:11],3,3)
    T = readtxt(c[11:14],3,1)
    f.close()
    size = (1280,720)
    f1 = (left_camera_matrix[0,0]+left_camera_matrix[1,1])/2
    f2 = (right_camera_matrix[0,0]+right_camera_matrix[1,1])/2
    R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(left_camera_matrix, left_distortion,
                                                                      right_camera_matrix, right_distortion, size, R,
                                                                      T)
    # 计算更正map
    left_map1, left_map2 = cv2.initUndistortRectifyMap(left_camera_matrix, left_distortion, R1, P1, size, cv2.CV_16SC2)
    right_map1, right_map2 = cv2.initUndistortRectifyMap(right_camera_matrix, right_distortion, R2, P2, size, cv2.CV_16SC2)
    return left_map1, left_map2,right_map1, right_map2,f1,f2

left_map1, left_map2,right_map1, right_map2,f1,f2=cameraCali()


def recheck(img_left2,img_right2):
    imgL2 = cv2.remap(img_left2, left_map1, left_map2, cv2.INTER_LINEAR)
    imgR2 = cv2.remap(img_right2, right_map1, right_map2, cv2.INTER_LINEAR)
    
    circles_left2 = cv2.HoughCircles(imgL2, cv2.HOUGH_GRADIENT, 1, 20,\
                               param1=100, param2=20, minRadius=10,maxRadius=30)
    
    circles_right2 = cv2.HoughCircles(imgR2, cv2.HOUGH_GRADIENT, 1, 20,\
                               param1=100, param2=20, minRadius=10,maxRadius=30)
    for i in circles_left2[0,:,:]:
        cv2.circle(imgL2, (i[0], i[1]), i[2], (0, 0, 255), 1)
        cv2.circle(imgL2, (i[0], i[1]), 2, (0, 0, 255), 1)
    
    for i in circles_right2[0,:,:]:
        cv2.circle(imgR2, (i[0], i[1]), i[2], (0, 0, 255), 1)
        cv2.circle(imgR2, (i[0], i[1]), 2, (0, 0, 255), 1)
    #图像水平拼接
    img2 = np.hstack((imgL2,imgR2))
    cv2.imwrite('p1.jpg',img2)
        
    if (circles_left2.shape[1] != 9)|(circles_right2.shape[1] != 9):   #异常检测
        print('The number of points is error ! It should be 9!')
        sys.exit(0)    
    
    a1=np.mean(circles_left2,axis=1)
    a2=np.mean(circles_right2,axis=1)
    
    
    fid = open('result.txt','w+')
    fid.write('the central vertical difference is '+str(a1[0,1]-a2[0,1]))
    fid.close()







