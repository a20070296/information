# -*- coding: utf-8 -*-


import numpy as np
import cv2
import sys
import math

def cameraCali():
    def readtxt(P,m,n):
        r=np.zeros((m,n))
        for i in range(len(P)):
            c=P[i].strip('\n').split(',')
            r[i,:]=c[:]
        return r
        
    f=open('cameraconfig.txt')
    c=f.readlines()
    left_camera_matrix = readtxt(c[0:3],3,3)
    left_distortion=readtxt(c[3:4],1,5)
    right_camera_matrix = readtxt(c[4:7],3,3)
    right_distortion=readtxt(c[7:8],1,5)
    R = readtxt(c[8:11],3,3)
    T = readtxt(c[11:14],3,1)
    f.close()
    size = (1280,720)
    f1 = (left_camera_matrix[0,0]+left_camera_matrix[1,1])/2
    f2 = (right_camera_matrix[0,0]+right_camera_matrix[1,1])/2
    R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(left_camera_matrix, left_distortion,
                                                                      right_camera_matrix, right_distortion, size, R,
                                                                      T)
    # 计算更正map
    left_map1, left_map2 = cv2.initUndistortRectifyMap(left_camera_matrix, left_distortion, R1, P1, size, cv2.CV_16SC2)
    right_map1, right_map2 = cv2.initUndistortRectifyMap(right_camera_matrix, right_distortion, R2, P2, size, cv2.CV_16SC2)
    return left_map1, left_map2,right_map1, right_map2,f1,f2

left_map1, left_map2,right_map1, right_map2,f1,f2=cameraCali()

def cv_show(name,img):
    cv2.imshow(name,img)
    cv2.waitKey(500)
    cv2.destroyAllWindows()

def re_sort(w0):  #重新排序
    w1=w0[:,np.argsort(w0[0,:,0]),:] #第一列排序
    w11=w1[0,0:3,:]
    w12=w1[0,3:6,:]
    w13=w1[0,6:9,:]
    w11=w11[np.argsort(w11[0:3,1]),:]
    w12=w12[np.argsort(w12[0:3,1]),:]
    w13=w13[np.argsort(w13[0:3,1]),:]
    r0=np.concatenate((w11,w12,w13),axis=0)
    return r0
#process picture...

def caliVR(img_left,img_right):
    
    imgL = cv2.remap(img_left, left_map1, left_map2, cv2.INTER_LINEAR)
    imgR = cv2.remap(img_right, right_map1, right_map2, cv2.INTER_LINEAR)
    
    rows,cols = imgL.shape
    
    #find circles ...
    as1 = 0.7    #match with 9 points picture
    circles_left = cv2.HoughCircles(imgL, cv2.HOUGH_GRADIENT, 1, 20,\
                               param1=100, param2=20, minRadius=10,maxRadius=30)
    
    circles_right = cv2.HoughCircles(imgR, cv2.HOUGH_GRADIENT, 1, 20,\
                               param1=100, param2=20, minRadius=10,maxRadius=30)
    
    for i in circles_left[0,:,:]:
        cv2.circle(imgL, (i[0], i[1]), i[2], (0, 0, 255), 1)
        cv2.circle(imgL, (i[0], i[1]), 2, (0, 0, 255), 1)
    
    cv_show("left",imgL)
    for i in circles_right[0,:,:]:
        cv2.circle(imgR, (i[0], i[1]), i[2], (0, 0, 255), 1)
        cv2.circle(imgR, (i[0], i[1]), 2, (0, 0, 255), 1)
    
    cv_show("rigth",imgR)
    cv2.imwrite('ul.jpg', imgL)
    cv2.imwrite('ur.jpg', imgR)
    
    if (circles_left.shape[1] != 9)|(circles_right.shape[1] != 9):   #异常检测
        print('The number of points is error ! It should be 9!')
        sys.exit(0)    
        
    b_left = re_sort(circles_left)[:,0:2]
    b_right= re_sort(circles_right)[:,0:2]
    #camera---PL
    
    def Cail_PL(f,b):  #计算投影矩阵及Z轴旋转量
        bl = np.mean(b[0:3,:],axis=0)
        br = np.mean(b[6:9,:],axis=0)
        bt = np.mean(b[0::3,:],axis=0)
        bb = np.mean(b[2::3,:],axis=0)
        lx = (np.linalg.norm(bl-br))/as1
        ly = (np.linalg.norm(bt-bb))/as1
        x0,y0 = b[4,:]
        cx0,cy0 = cols/2,rows/2
        dt0 = cy0 - y0
        ds0 = cx0 - x0
        P=np.zeros(5)
        zoom = 0.064/lx
        P[0] = f * zoom
        P[1] = lx * zoom
        P[2] = ly * zoom
        P[3] = ds0 / lx
        P[4] = dt0 / ly
        st = ((br[1]-bl[1])/(lx*as1)+(bt[0]-bb[0])/(ly*as1))
        thetaZ = math.degrees(math.asin(st))
        return P,thetaZ
    
    
    PL,thetaZ1 = Cail_PL(f1,b_left)
    PR,thetaZ2 = Cail_PL(f2,b_right)
    return PL,PR



