# -*- coding: utf-8 -*-
"""
Created on Mon May 11 10:43:59 2020

@author: K
"""

import cv2
import numpy as np
import glob
import time
#获取标定板角点的位置
# 阈值
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
#输入棋盘格数目和大小
w,h = 15,8
scale = 24.1

import tkinter
def a():
    form.destroy()
    
form=tkinter.Tk()
form.title('输入棋盘格数目和大小')
form.minsize(300,200)

l1 = tkinter.Label(form,text="棋盘格水平格数：").pack()
num_x = tkinter.StringVar()
entryx = tkinter.Entry(form,textvariable = num_x).pack()
num_x.set("16")

l2 = tkinter.Label(form,text="棋盘格竖直格数：").pack()
num_y = tkinter.StringVar()
entryy = tkinter.Entry(form,textvariable = num_y).pack()
num_y.set("9")

l2 = tkinter.Label(form,text="棋盘格大小（ mm ）：").pack()
num_z = tkinter.StringVar()
entryz = tkinter.Entry(form,textvariable = num_z).pack()
num_z.set("24.1")

bt1=tkinter.Button(form,text='确定',command = a,background='red' )
bt1.pack(padx=50,pady=20, side=tkinter.BOTTOM)
form.mainloop()
w = int(num_x.get())-1
h = int(num_y.get())-1
scale = float(num_z.get())


######
objp = np.zeros((w * h, 3), np.float32)
objp[:, :2] = np.mgrid[0:(w-1)*scale:complex(0,w),0:(h-1)*scale:complex(0,h)].T.reshape(-1, 2)
objpoints = [] # 存储3D点
objpoints1 = [] # 存储3D点
imgpoints = [] # 存储左侧相机2D点
imgpoints1 = [] # 存储右侧相机2D点

images = glob.glob("./pic/left/*.bmp")

for fname in images:
    img = cv2.imread(fname,0)
    gray = img
    #gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
       # 找到棋盘格角点
    ret, corners = cv2.findChessboardCorners(gray, (w,h), None)
    # 如果找到足够点对，将其存储起来
    if ret == True:
        cv2.cornerSubPix(gray,corners,(11,11),(-1,-1),criteria)
        #cv2.find4QuadCornerSubpix(gray,corners,(11,11))
        objpoints.append(objp)
        imgpoints.append(corners)
        # 将角点在图像上显示
        #cv2.drawChessboardCorners(img, (w,h), corners, ret)
        #cv2.imshow('findCorners',img)
        #cv2.waitKey(1)
      
cv2.destroyAllWindows()
size = gray.shape[::-1]
ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)
#print("ret:", ret)
#print("mtx:\n", mtx) # 内参数矩阵
#print("dist:\n", dist)  # 畸变系数   distortion cofficients = (k_1,k_2,p_1,p_2,k_3)

#右侧相机内参标定
images1 = glob.glob("./pic/right/*.bmp")

for fname in images1:
    img = cv2.imread(fname,0)
    gray = img
    #gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
       # 找到棋盘格角点
    ret, corners = cv2.findChessboardCorners(gray, (w,h), None)
    # 如果找到足够点对，将其存储起来
    if ret == True:
        cv2.cornerSubPix(gray,corners,(11,11),(-1,-1),criteria)
        #cv2.find4QuadCornerSubpix(gray,corners,(11,11))
        objpoints1.append(objp)
        imgpoints1.append(corners)
        # 将角点在图像上显示
#        cv2.drawChessboardCorners(img, (w,h), corners, ret)
#        cv2.imshow('findCorners',img)
#        cv2.waitKey(1)
#cv2.destroyAllWindows()

ret1, mtx1, dist1, rvecs1, tvecs1 = cv2.calibrateCamera(objpoints1, imgpoints1, gray.shape[::-1], None, None)
#print("ret1:", ret1)
#print("mtx1:\n", mtx1) # 内参数矩阵
#print("dist1:\n", dist1)  # 畸变系数   distortion cofficients = (k_1,k_2,p_1,p_2,k_3)
#print("-------------------计算反向投影误差-----------------------")

#双目立体矫正及左右相机内参进一步修正
rms, C1, dist1, C2, dist2, R, T, E,F = cv2.stereoCalibrate(objpoints, imgpoints, imgpoints1, mtx, dist,mtx1, dist1,gray.shape[::-1],flags=cv2.CALIB_USE_INTRINSIC_GUESS )
#R1,R2,P1,P2,Q,validPixROI1,validPixROI2 = cv2.stereoRectify(C1,dist1,C2,dist2,size,R,T,alpha = -1)

#打印出相机内参
def printintxt(P,f):
    for i in range(0,P.shape[0]):
        for j in range(0,P.shape[1]):
            f.write(str(P[i,j]))
            if j<P.shape[1]-1:
                f.write(',')
            else:
                f.write('\n')

file=open('cameraconfig.txt','w')

printintxt(C1,file)
printintxt(dist1,file)
printintxt(C2,file)
printintxt(dist2,file)
printintxt(R,file)
printintxt(T,file)
# file.write(str(size)) ??
file.close()

print("已打印相机内参 ...")