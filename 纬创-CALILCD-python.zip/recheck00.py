# -*- coding: utf-8 -*-
"""
Created on Wed May  6 17:21:11 2020

@author: K
"""
import camera_configs
import cv2
import numpy as np

def cv_show(img):
    cv2.imshow('name',img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

#undistortion 

w,h = 15,8

img_left2 = cv2.imread('L01.bmp',0)
img_right2 = cv2.imread('R01.bmp',0)

imgL2 = cv2.remap(img_left2, camera_configs.left_map1, camera_configs.left_map2, cv2.INTER_LINEAR)
imgR2 = cv2.remap(img_right2, camera_configs.right_map1, camera_configs.right_map2, cv2.INTER_LINEAR)

#锐化
kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]], np.float32) #定义一个核
dst12 = cv2.filter2D(dst11, -1, kernel=kernel)
#去噪

#直方图均衡化
dst2 = cv2.equalizeHist(dst)

#角点检测
ret, corners = cv2.findChessboardCorners(cl1, (w,h), None)

cv_show(img_right2)
dst11 = cv2.medianBlur(dst,5)

#自适应直方图均衡
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
cl1 = clahe.apply(imgR2)
cv_show(cl1)


blur1 = cv2.GaussianBlur(imgR2, (5,5), 0)

circles_right2 = cv2.HoughCircles(cl1, cv2.HOUGH_GRADIENT, 1, 20,\
                           param1=100, param2=20, minRadius=10,maxRadius=30)


#txt追加
fid = open('CameraUUID.txt','a+')
fid.write('leftpic'+'\n')
fid.close()


#按钮
import tkinter
import os

def a():
    print('left camera')
    fid = open('CameraUUID.txt','a+')
    fid.write('leftpic'+'\n')
    fid.close()
    #form.quit()
    form.destroy()
    os.system(r'taskkill /F /IM CameraTool.exe')

def b():
    print('rigth camera')
    fid = open('CameraUUID.txt','a+')
    fid.write('rightpic'+'\n')
    fid.close()
    #form.quit()
    form.destroy()
    os.system(r'taskkill /F /IM CameraTool.exe')


form=tkinter.Tk()
form.title('点击选择哪个相机')
form.minsize(300,100)
bt1=tkinter.Button(form,text='left camera',command = a,background='red' )
bt1.pack(padx=50,pady=50, side=tkinter.LEFT)
bt1=tkinter.Button(form,text='right camera',command = b,background='yellow' )
bt1.pack(padx=50,pady=50,side=tkinter.RIGHT)

form.mainloop()


#读取txt文件
f=open('CameraUUID.txt')
c=f.readlines()

d=str(c[-1])

################读取txt
import cv2
import numpy as np

def cameraCali():
    def readtxt(P,m,n):
        r=np.zeros((m,n))
        for i in range(len(P)):
            c=P[i].strip('\n').split(',')
            r[i,:]=c[:]
        return r
        
    f=open('cameraconfig.txt')
    c=f.readlines()
    left_camera_matrix = readtxt(c[0:3],3,3)
    left_distortion=readtxt(c[3:4],1,5)
    right_camera_matrix = readtxt(c[4:7],3,3)
    right_distortion=readtxt(c[7:8],1,5)
    R = readtxt(c[8:11],3,3)
    T = readtxt(c[11:14],3,1)
    f.close()
    size = (1280,720)
    f1 = (left_camera_matrix[0,0]+left_camera_matrix[1,1])/2
    f2 = (right_camera_matrix[0,0]+right_camera_matrix[1,1])/2
    R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(left_camera_matrix, left_distortion,
                                                                      right_camera_matrix, right_distortion, size, R,
                                                                      T)
    # 计算更正map
    left_map1, left_map2 = cv2.initUndistortRectifyMap(left_camera_matrix, left_distortion, R1, P1, size, cv2.CV_16SC2)
    right_map1, right_map2 = cv2.initUndistortRectifyMap(right_camera_matrix, right_distortion, R2, P2, size, cv2.CV_16SC2)
    return left_map1, left_map2,right_map1, right_map2,f1,f2

left_map1, left_map2,right_map1, right_map2,f1,f2=cameraCali()
########################
#字符串分割
c3 = c[1].strip('\n').split(',')    
len(c[3:3])

with open('cameraconfig.txt','w') as file:
    write_str = '%f %f\n'%(C1,C2)
    file.write(write_str)

print(map(float,c3))

dist1.shape[1]


range(3)

#一种方法，没法追加
np.savetxt("cameraconfig.txt", C1,fmt='%f',delimiter=',',newline='\n')
c=np.loadtxt('cameraconfig.txt',delimiter=',')
























